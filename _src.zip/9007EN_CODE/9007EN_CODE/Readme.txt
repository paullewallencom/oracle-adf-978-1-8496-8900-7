10, and 11 do not have code files for them.
in case HR account is locked used the steps to unlock
http://docs.oracle.com/cd/E17781_01/admin.112/e18585/toc.htm#BJFDGBHJ
demobld.sql is added to create HRSchema
